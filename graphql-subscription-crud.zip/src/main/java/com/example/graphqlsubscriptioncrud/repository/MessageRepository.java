package com.example.graphqlsubscriptioncrud.repository;

import com.example.graphqlsubscriptioncrud.model.Message;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Repository
public class MessageRepository {
    private final Map<String, Message> messages = new HashMap<>();

    public Message createMessage(String content) {
        String id = UUID.randomUUID().toString();
        Message message = new Message(id, content);
        messages.put(id, message);
        return message;
    }

    public Message updateMessage(String id, String content) {
        Message message = messages.get(id);
        if (message != null) {
            message.setContent(content);
        }
        return message;
    }

    public boolean deleteMessage(String id) {
        return messages.remove(id) != null;
    }

    public Message getMessage(String id) {
        return messages.get(id);
    }

    public Map<String, Message> getMessages() {
        return messages;
    }
}