package com.example.graphqlsubscriptioncrud.resolver;

import com.coxautodev.graphql.tools.GraphQLSubscriptionResolver;
import com.example.graphqlsubscriptioncrud.model.Message;
import org.reactivestreams.Publisher;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;

import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Component
public class SubscriptionResolver implements GraphQLSubscriptionResolver {

    private final ConcurrentLinkedQueue<FluxSink<Message>> subscribers = new ConcurrentLinkedQueue<>();

    public SubscriptionResolver() {
        Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(() -> {
            Message message = new Message(UUID.randomUUID().toString(), "New message at " + System.currentTimeMillis());
            for (FluxSink<Message> subscriber : subscribers) {
                subscriber.next(message);
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    public Publisher<Message> messageAdded() {
        return Flux.create(subscriber -> {
            subscribers.add(subscriber.onDispose(() -> subscribers.remove(subscriber)));
        });
    }
}