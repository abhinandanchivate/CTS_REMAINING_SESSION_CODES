package com.example.graphqlsubscriptioncrud.resolver;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.example.graphqlsubscriptioncrud.model.Message;
import com.example.graphqlsubscriptioncrud.repository.MessageRepository;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class QueryResolver implements GraphQLQueryResolver {

    private final MessageRepository messageRepository;

    public QueryResolver(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    public List<Message> getMessages() {
        return messageRepository.getMessages().values().stream().collect(Collectors.toList());
    }

    public Message getMessage(String id) {
        return messageRepository.getMessage(id);
    }
}