package com.example.graphqlsubscriptioncrud.resolver;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.example.graphqlsubscriptioncrud.model.Message;
import com.example.graphqlsubscriptioncrud.repository.MessageRepository;
import org.springframework.stereotype.Component;

@Component
public class MutationResolver implements GraphQLMutationResolver {

    private final MessageRepository messageRepository;

    public MutationResolver(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    public Message createMessage(String content) {
        return messageRepository.createMessage(content);
    }

    public Message updateMessage(String id, String content) {
        return messageRepository.updateMessage(id, content);
    }

    public boolean deleteMessage(String id) {
        return messageRepository.deleteMessage(id);
    }
}