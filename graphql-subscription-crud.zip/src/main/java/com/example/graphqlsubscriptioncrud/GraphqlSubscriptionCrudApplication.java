package com.example.graphqlsubscriptioncrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphqlSubscriptionCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(GraphqlSubscriptionCrudApplication.class, args);
    }
}