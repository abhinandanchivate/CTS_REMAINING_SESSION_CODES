package com.example.graphqlsubscriptioncrud.config;

import com.graphql.spring.boot.starter.subscriptions.GraphQLWebsocketSubscriptionProtocolFactory;
import graphql.kickstart.execution.GraphQLInvoker;
import graphql.kickstart.execution.subscriptions.apollo.ApolloSubscriptionConnectionListener;
import graphql.kickstart.execution.subscriptions.apollo.ApolloSubscriptionProtocolFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GraphQLConfig {

    @Bean
    public ApolloSubscriptionProtocolFactory subscriptionProtocolFactory(GraphQLInvoker graphQLInvoker) {
        return new GraphQLWebsocketSubscriptionProtocolFactory(graphQLInvoker, null);
    }
}